//print("hola mundo!")
//hablar("hola mundo!")

//imprimir resultado
// document.getElementById("resultado").value="hola mundo!"
// nro1=parseFloat(document.getElementById("numero1").value)
// nro2=parseFloat(document.getElementById("numero2").value)
// resultado=nro1+nro2
// document.getElementById("resultado").value=resultado

function sumar(){
    nro1=parseFloat(document.getElementById("numero1").value)
    nro2=parseFloat(document.getElementById("numero2").value)
    resultado=nro1+nro2
    document.getElementById("resultado").value=resultado
    hablar(resultado)
}

function restar(){
    nro1=parseFloat(document.getElementById("numero1").value)
    nro2=parseFloat(document.getElementById("numero2").value)
    resultado=nro1-nro2
    document.getElementById("resultado").value=resultado
    hablar(resultado)
}

function multiplicar(){
    nro1=parseFloat(document.getElementById("numero1").value)
    nro2=parseFloat(document.getElementById("numero2").value)
    resultado=nro1*nro2
    document.getElementById("resultado").value=resultado
    hablar(resultado)
}

function dividir(){
    nro1=parseFloat(document.getElementById("numero1").value)
    nro2=parseFloat(document.getElementById("numero2").value)
    if(nro2!=0)     resultado=nro1/nro2
    else            resultado="Error / 0"
    document.getElementById("resultado").value=resultado
    hablar(resultado)
}